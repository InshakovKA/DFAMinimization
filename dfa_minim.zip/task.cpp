#include "api.hpp"
#include <string>

DFA dfa_minim(DFA &d) {
  return d;
}
